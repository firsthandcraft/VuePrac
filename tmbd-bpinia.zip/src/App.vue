<script setup></script>

<template>
  <nav>
    <RouterLink to="/">Home</RouterLink>
    <RouterLink to="/about">About</RouterLink>
    <RouterLink to="/api">Api</RouterLink>
  </nav>

  <RouterView />
</template>
