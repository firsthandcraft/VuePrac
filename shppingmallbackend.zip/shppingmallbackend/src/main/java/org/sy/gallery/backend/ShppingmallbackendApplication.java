package org.sy.gallery.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShppingmallbackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShppingmallbackendApplication.class, args);
    }

}
