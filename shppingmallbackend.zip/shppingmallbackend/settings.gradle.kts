rootProject.name = "shppingmallbackend"
